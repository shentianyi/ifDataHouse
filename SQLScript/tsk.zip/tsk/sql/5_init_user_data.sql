INSERT INTO [Leoni_Tsk_JN].[dbo].[User]
           ([Name]
           ,[Password]
           ,[Role])
     VALUES
           ('TskAdmin'
           ,'admin@'
           ,'admin')
GO


