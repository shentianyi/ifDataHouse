use Tsk_Junnuo
go

INSERT INTO  [User]
           ([Name]
           ,[Password]
           ,[Role])
     VALUES
           ('TskAdmin'
           ,'admin@'
           ,'admin')
GO
